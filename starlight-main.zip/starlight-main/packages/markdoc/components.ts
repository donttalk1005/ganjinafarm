export { default as Code } from './Code.astro';
export { default as Heading } from '@astrojs/starlight/components/AnchorHeading.astro';

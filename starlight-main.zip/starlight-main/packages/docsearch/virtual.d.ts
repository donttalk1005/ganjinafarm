declare module 'virtual:starlight/docsearch-config' {
	const DocSearchClientOptions: import('./index').DocSearchClientOptions;
	export default DocSearchClientOptions;
}

import { defineVitestConfig } from '../test-config';

export default defineVitestConfig({ title: 'Basics' });

import { defineVitestConfig } from '../test-config';

export default defineVitestConfig({ title: 'Middleware' });

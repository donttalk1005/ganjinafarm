import { defineVitestConfig } from '../test-config';

export default defineVitestConfig({
	title: 'sidebar slug error',
	sidebar: ['/getting-started/'],
});

export default ['__tests__/*/vitest.config.ts'];

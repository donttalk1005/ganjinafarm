---
title: Individual Markdown Page
---

# Individual Markdown Page

## Description

This page is an [individual Markdown page](https://docs.astro.build/en/guides/markdown-content/#individual-markdown-pages).
It is used to test that various remark/rehype plugins are not transforming individual Markdown pages.

:::note
This is a note using Starlight Markdown aside syntax.
:::

This is an `inline code` example.

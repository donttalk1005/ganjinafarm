---
title: Home Page
template: splash
lastUpdate: true
hero:
  title: Make your docs shine with Starlight
  tagline: Everything you need to build a stellar documentation website. Fast, accessible, and easy-to-use.
  actions:
    - text: Get started
      icon: right-arrow
      variant: primary
      link: /getting-started/
    - text: View on GitHub
      icon: external
      link: https://github.com/withastro/starlight
---

Home page content

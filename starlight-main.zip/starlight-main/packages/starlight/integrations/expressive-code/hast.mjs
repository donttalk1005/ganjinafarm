/**
 * @file This file is exported by Starlight as `@astrojs/starlight/expressive-code/hast`.
 *
 * Note: This file is intentionally not a TypeScript module to allow access to all exported
 * functionality even if TypeScript is not available, e.g. from the `ec.config.mjs` file
 * that does not get processed by Vite.
 */

export * from 'astro-expressive-code/hast';

/**
 * @file This file provides the types for Starlight's `@astrojs/starlight/expressive-code/hast` export.
 */

export * from 'astro-expressive-code/hast';

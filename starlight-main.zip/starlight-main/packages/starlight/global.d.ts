export declare global {
	var StarlightThemeProvider: {
		updatePickers(theme?: string): void;
	};
}
